import com.github.tototoshi.csv._
import java.io.File
import org.nspl.*
import org.nspl.awtrenderer.*
import org.nspl.data.HistogramData

implicit object MyFormat extends DefaultCSVFormat {
  override val delimiter = ';'
}

  object App {
    @main
    def trabajogr2b(): Unit = {
      val pathDataFile = "C://Personal//ArchivoPIntegrador//dsPartidosYGoles.csv"
      val reader = CSVReader.open(new File(pathDataFile))
      val contentFile: List[Map[String, String]] = reader.allWithHeaders()
      reader.close()
      println((contentFile.take(1)))

      def datosGrafica(ruta: String): List[(String, Int)] = {
        val reader = CSVReader.open(new File(ruta))
        val data: List[Map[String, String]] = reader.allWithHeaders()
        reader.close()

        val dataGoles = data
          .map(row => (
            row("tournaments_tournament_name"),
            row("matches_match_id"),
            row("matches_home_team_score"),
            row("matches_away_team_score")
          ))
          .distinct
          .map(t4 => (t4._1, t4._3.toInt + t4._4.toInt))
          .groupBy(_._1)
          .map(t2 => (t2._1, t2._2.map(_._2).sum))
          .toList
          .sortBy(_._1)

        dataGoles.foreach(println)
        dataGoles

      }
    
    val graficaGoles = xyplot(HistogramData(dataGoles, 10) -> bar)(
        par
          .xlab("Mundiales")
          .ylab("Goles")
          .main("Partidos por mundial")
      )
      pngToFile(new File("C://Personal//ArchivoPIntegrador//goles_mundial.png"), graficaGoles.build, 1000)

    }
    //datosGrafica("C://Personal//ArchivoPIntegrador//dsPartidosYGoles.csv")
  }

